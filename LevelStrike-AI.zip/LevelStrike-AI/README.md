# LevelStrike AI™ — Automated Trading Bot

This repository contains the full feature set and logic for **LevelStrike AI™**, a high-precision automated trading bot for binary options and market analysis.

## ✅ Features List

1. Strong Support & Resistance Detection  
2. Entry Based Only on 1-Minute Chart  
3. Manual + Auto Trading Modes  
4. Secure Access  
5. Daily & Weekly Trade Journals  
6. Alerts and Reminders  
7. Trading Time Filters  
8. Trend Detection & Filters  
9. Asset Support  
10. TradingView Integration  
11. TradingView Chart Snapshots  
12. Future Signal Module  
13. Built-in Custom Calculator  
14. Profit/Loss Simulator  
15. Daily + Weekly Goal Tracker  
16. Signal Tags  
17. Theme Customization  
18. Email Notifications  
19. Personalized Quotex Integration  
20. Smart Auto-Mode Logic

See full documentation in the `docs/` folder.
